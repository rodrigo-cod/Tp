# Aurora Café — Proyecto final

Sitio web responsive para la carta de una cafetería. Es una versión ampliada del TP n.º 1 de cafetería.

## Cómo abrirlo
1. Descargá y descomprimí el ZIP.
2. Abrí `index.html` en tu navegador.
3. Para editarlo, abrí la carpeta completa en Visual Studio Code.

## Archivos
- `index.html`: estructura y contenido de la página.
- `css/estilos.css`: diseño, estilos y adaptación responsive.
- `js/app.js`: filtros, búsqueda, menú móvil y pedido de demostración.

## Contenidos de CSS aplicados
- Selectores y especificidad.
- Modelo de caja con `box-sizing: border-box`.
- Unidades relativas (`rem`, `%`, `vw`, `clamp`).
- Tipografías, paleta de colores y variables CSS.
- Flexbox y CSS Grid.
- Posicionamiento `sticky`, `fixed`, `relative` y `absolute`.
- Media queries para tablet y celular.

## Funcionalidades
- Filtrado por categoría.
- Búsqueda de productos.
- Agregar productos a un pedido de demostración.
- Resumen y total del pedido.
- Navegación adaptable a pantallas pequeñas.

## Personalización
Los nombres, precios, dirección y horarios son datos de ejemplo para el trabajo práctico. Las fotografías y tipografías se cargan desde servicios externos, por lo que se necesita conexión a Internet para verlas.

Proyecto educativo — Generación T / Campus GT.
