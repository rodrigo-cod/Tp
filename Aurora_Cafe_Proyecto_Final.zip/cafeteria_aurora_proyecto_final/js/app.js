const products = [];
const grid = document.querySelector("#productGrid");
const filterButtons = [...document.querySelectorAll(".filter-btn")];
const searchInput = document.querySelector("#searchInput");
const emptyState = document.querySelector("#emptyState");
const cartBar = document.querySelector("#cartBar");
const cartCount = document.querySelector("#cartCount");
const cartTotal = document.querySelector("#cartTotal");
const orderDialog = document.querySelector("#orderDialog");
const orderList = document.querySelector("#orderList");
const dialogTotal = document.querySelector("#dialogTotal");
let activeFilter = "todos";

const money = value => new Intl.NumberFormat("es-AR", {
  style: "currency", currency: "ARS", maximumFractionDigits: 0
}).format(value);

function renderCart() {
  const count = products.reduce((sum, item) => sum + item.quantity, 0);
  const total = products.reduce((sum, item) => sum + item.price * item.quantity, 0);
  cartCount.textContent = `${count} ${count === 1 ? "producto" : "productos"}`;
  cartTotal.textContent = `Total: ${money(total)}`;
  dialogTotal.textContent = money(total);
  cartBar.classList.toggle("visible", count > 0);
  orderList.innerHTML = products.map(item =>
    `<li><span>${item.name} × ${item.quantity}</span><strong>${money(item.price * item.quantity)}</strong></li>`
  ).join("");
}

function filterProducts() {
  const term = searchInput.value.trim().toLocaleLowerCase("es");
  let visible = 0;
  document.querySelectorAll(".product-card").forEach(card => {
    const categoryMatches = activeFilter === "todos" || card.dataset.category === activeFilter;
    const textMatches = card.dataset.name.toLocaleLowerCase("es").includes(term);
    const show = categoryMatches && textMatches;
    card.hidden = !show;
    if (show) visible++;
  });
  emptyState.hidden = visible !== 0;
}

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach(item => item.classList.toggle("active", item === button));
    filterProducts();
  });
});
searchInput.addEventListener("input", filterProducts);

document.querySelectorAll(".add-btn").forEach(button => {
  button.addEventListener("click", () => {
    const name = button.dataset.product;
    const price = Number(button.dataset.price);
    const existing = products.find(item => item.name === name);
    if (existing) existing.quantity++;
    else products.push({ name, price, quantity: 1 });
    renderCart();
    button.innerHTML = 'Agregado <span>✓</span>';
    window.setTimeout(() => button.innerHTML = 'Agregar <span>+</span>', 900);
  });
});

document.querySelector("#viewOrder").addEventListener("click", () => orderDialog.showModal());
document.querySelector("#closeDialog").addEventListener("click", () => orderDialog.close());
document.querySelector("#finishOrder").addEventListener("click", () => {
  products.length = 0;
  renderCart();
  orderDialog.close();
  document.querySelectorAll(".add-btn").forEach(button => button.innerHTML = 'Agregar <span>+</span>');
});

const menuToggle = document.querySelector("#menuToggle");
const mainNav = document.querySelector("#mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));
